package com.ama_patrol.presentation.menu.monitoring

import androidx.lifecycle.ViewModel

class MonitoringViewModel : ViewModel() {

}