package com.ama_patrol.presentation.menu.manage

class KelolaanDetailsActivity {
}