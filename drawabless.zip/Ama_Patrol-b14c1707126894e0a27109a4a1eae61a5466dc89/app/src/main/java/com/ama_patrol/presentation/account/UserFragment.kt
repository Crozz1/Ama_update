package com.ama_patrol.presentation.account

class UserFragment {
}