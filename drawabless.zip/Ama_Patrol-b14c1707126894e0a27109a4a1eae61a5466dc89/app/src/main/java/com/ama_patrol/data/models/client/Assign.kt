package com.ama_patrol.data.models.client


class Assign (

    var id: String? = null,
    var idAgen: String? = null,
    var nik: String?    = null,
    var nAgen: String?  = null,
    var OAgen: String?  = null,
    var tgl: String?    = null,
    var nAma: String?   = null,
    var alamat :String? = null,
    var noHp:String?    = null,
    var lUsaha: String? = null,
    var FLusaha: String?= null
)
//    constructor() { }
//
//    constructor(namaAgen: String?, tanggal: String?, namaAma: String?) {
//    nAgen = namaAgen
//    tgl = tanggal
//    nAma = namaAma
//}


